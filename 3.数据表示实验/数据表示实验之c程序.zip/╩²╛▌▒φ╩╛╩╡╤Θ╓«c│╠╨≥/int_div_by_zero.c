//file: int_div_by_zero.c
#include "stdio.h"
main()
{
 int a=1; a=a/0;
 printf("a=%d",a);
 return;
}
